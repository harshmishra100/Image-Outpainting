import os
import shutil
from sklearn.model_selection import train_test_split

# Define paths
input_dir = r'C:\Users\govin\DeepLearning\resized_images'  # Replace with your input folder path
home_dir = os.path.expanduser('~')  # Home directory
model_save_path = os.path.join(home_dir, 'outpaint_model')  # Save model in home directory
html_save_path = os.path.join(home_dir, 'outpaint_html')
train_dir = os.path.join(input_dir, 'train')
val_dir = os.path.join(input_dir, 'val')
test_dir = os.path.join(input_dir, 'test')  # New test directory

# Create train, val, and test directories if they don't exist
os.makedirs(train_dir, exist_ok=True)
os.makedirs(val_dir, exist_ok=True)
os.makedirs(test_dir, exist_ok=True)

# Get list of all files in the input directory
all_files = [f for f in os.listdir(input_dir) if os.path.isfile(os.path.join(input_dir, f))]

# Split into train and temp sets (70% train, 30% temp for val and test)
train_files, temp_files = train_test_split(all_files, test_size=0.3, random_state=42)

# Split temp into val and test sets (66.67% val, 33.33% test of temp, which is 20% and 10% of total)
val_files, test_files = train_test_split(temp_files, test_size=0.333, random_state=42)

# Move files to the respective directories
for file_name in train_files:
    shutil.move(os.path.join(input_dir, file_name), os.path.join(train_dir, file_name))

for file_name in val_files:
    shutil.move(os.path.join(input_dir, file_name), os.path.join(val_dir, file_name))

for file_name in test_files:
    shutil.move(os.path.join(input_dir, file_name), os.path.join(test_dir, file_name))

print("Data successfully split into train, validation, and test sets.")
print(f"Model will be saved at: {model_save_path}")
print(f"HTML outputs will be saved at: {html_save_path}")
