myworld/Scripts/activate
conda activate myenv
train.py
pre-processing-crop_image.py
pre-prcessing_Compress.py
Forward3