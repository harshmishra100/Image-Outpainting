import os
import matplotlib.pyplot as plt
import numpy as np
from outpainting import *
import torch
import torchvision

def load_images_from_folder(folder_path, start_idx, end_idx):
    # List all files in the folder and sort them
    files = sorted([f for f in os.listdir(folder_path) if f.endswith(('.jpg', '.png'))])
    
    # Select files within the specified range
    selected_files = files[start_idx:end_idx]
    
    # Load images
    images = []
    for file in selected_files:
        img_path = os.path.join(folder_path, file)
        image = plt.imread(img_path)[:, :, :3]
        images.append(image)
    
    return images

def add_border_to_images(images, border_size=32, border_color=(128, 128, 128)):
    bordered_images = []
    for image in images:
        # Create a new image with border
        bordered_image = np.ones((image.shape[0] + 2 * border_size, image.shape[1] + 2 * border_size, 3), dtype=np.uint8)
        bordered_image[:, :] = border_color  # Fill with border color
        bordered_image[border_size:border_size + image.shape[0], border_size:border_size + image.shape[1]] = image  # Place original image
        bordered_images.append(bordered_image)
    return bordered_images

def process_and_display_grid(input_images, gt_images, model_path, save_path):
    # Load the model
    gen_model = load_model(model_path)
    print("Model loaded.")

    # Prepare to store output images
    output_images = []

    # Perform outpainting on each input image and collect outputs
    for input_img in input_images:
        output_img, blended_img = perform_outpaint(gen_model, input_img)
        output_images.append(blended_img)

    # Create bordered images for the first row
    bordered_input_images = add_border_to_images(input_images)

    # Plot the images in a grid
    num_images = len(input_images)
    fig, axes = plt.subplots(3, num_images, figsize=(15, 5))

    # Display Input, Output, and GT in respective rows with titles
    row_titles = ["Input", "Output", "GT"]
    for i in range(3):
        axes[i, 0].set_ylabel(row_titles[i], rotation=0, labelpad=30, size='large')

    for i in range(num_images):
        # Input image with border
        axes[0, i].imshow(bordered_input_images[i])
        axes[0, i].axis("off")

        # Outpainted Output image
        axes[1, i].imshow(output_images[i])
        axes[1, i].axis("off")

        # Ground Truth (GT) image
        axes[2, i].imshow(gt_images[i])
        axes[2, i].axis("off")

    plt.tight_layout()
    plt.savefig(save_path)
    plt.show()
    print(f"Grid saved to {save_path}")

if __name__ == '__main__':
    # Set folder path and model path
    folder_path = r'C:\Users\govin\DeepLearning\Demo_image'
    folder_path_gt = r'C:\Users\govin\DeepLearning\val'

    model_path = r'C:\Users\govin\DeepLearning\outpaint_models\G_199.pt'
    save_path = 'output_grid.jpg'

    # Define the range of images to process (e.g., process images from index 0 to 5)
    start_idx = 0  # Starting index of the range
    end_idx = start_idx + 5  # Number of images to process each time (5 in this example)

    # Load input and GT images from the folder within the specified range
    input_images = load_images_from_folder(folder_path, start_idx, end_idx)
    gt_images = load_images_from_folder(folder_path_gt, start_idx, end_idx)  # Assuming GT images are in the same range

    # Process images and display in grid
    process_and_display_grid(input_images, gt_images, model_path, save_path)
