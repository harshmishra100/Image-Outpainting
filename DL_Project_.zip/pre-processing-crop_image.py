import os
from PIL import Image
import numpy as np

# Set the directory where your images are stored and the target dimensions
input_directory = r"C:\Users\govin\DeepLearning\val"
output_directory = r"C:\Users\govin\DeepLearning\Demo_image"
target_size = (128, 128)  # Set your desired image size here

# Ensure the output directory exists
os.makedirs(output_directory, exist_ok=True)

# Function to load, crop, and normalize images
def preprocess_images(input_dir, output_dir, target_size):
    for filename in os.listdir(input_dir):
        # Only process files with common image extensions
        if filename.lower().endswith(('.png', '.jpg', '.jpeg')):
            file_path = os.path.join(input_dir, filename)
            
            # Open the image
            img = Image.open(file_path)

            # Calculate the center crop coordinates
            width, height = img.size
            new_width, new_height = target_size
            left = (width - new_width) / 2
            top = (height - new_height) / 2
            right = (width + new_width) / 2
            bottom = (height + new_height) / 2
            
            # Crop the image
            img_cropped = img.crop((left, top, right, bottom))
            
            # Convert image to a numpy array and normalize pixel values to [0, 1]
            img_array = np.array(img_cropped) / 255.0
            
            # Convert back to Image format
            img_normalized = Image.fromarray((img_array * 255).astype(np.uint8))
            
            # Save the processed image
            save_path = os.path.join(output_dir, filename)
            img_normalized.save(save_path, format='JPEG')
            print(f"Processed and saved: {save_path}")

# Run the preprocessing
preprocess_images(input_directory, output_directory, target_size)
